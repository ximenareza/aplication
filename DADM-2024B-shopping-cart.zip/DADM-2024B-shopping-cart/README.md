<center>
    <img src="./md/images/ITGAMBanner.png" alt="Itgam Banner">
</center>

# Shopping Cart 🛒 Project

Proyecto didactico para el curso de
Desarrollo de apps en dispositivos móviles

## Autor

Ivan Rivalcoba 🐦‍🔥